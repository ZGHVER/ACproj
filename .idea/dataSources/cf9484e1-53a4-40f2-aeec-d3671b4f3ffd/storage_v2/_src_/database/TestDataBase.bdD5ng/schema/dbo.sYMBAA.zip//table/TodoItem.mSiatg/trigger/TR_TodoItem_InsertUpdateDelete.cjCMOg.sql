CREATE TRIGGER [TR_TodoItem_InsertUpdateDelete] ON [dbo].[TodoItem]
		   AFTER INSERT, UPDATE, DELETE
		AS
		BEGIN
			SET NOCOUNT ON;
			IF TRIGGER_NESTLEVEL() > 3 RETURN;

			UPDATE [dbo].[TodoItem] SET [dbo].[TodoItem].[updatedAt] = CONVERT (DATETIMEOFFSET(3), SYSUTCDATETIME())
			FROM INSERTED
			WHERE INSERTED.id = [dbo].[TodoItem].[id]
		END
go

